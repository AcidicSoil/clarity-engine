veil
cast entropy
cut "no clear object"
resume
scan
flag "fragmented chain"
log
save
query phase:REVEAL
dashboard
design
override