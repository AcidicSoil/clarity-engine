# Prompt Snippets

Copy-paste clarity ritual prompts for Cursor.