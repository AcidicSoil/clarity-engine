# Setup Guide

Step-by-step to connect LM Studio → Cursor via Ngrok.