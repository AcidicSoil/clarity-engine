# Ritual Workflows

Five clarity-driven use cases inside Cursor.